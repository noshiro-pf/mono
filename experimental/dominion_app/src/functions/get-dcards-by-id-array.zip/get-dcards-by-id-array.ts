import { List as IList } from 'immutable';
import { DCard } from '../../types/dominion/online-game/dcard';

// idArrayの順番で取得
export const getDCardsByIdArray = (
  dcards: IList<DCard>,
  idArray: IList<number>,
): IList<DCard> =>
  idArray.map(id => dcards.find(c => c.id === id) || new DCard())
         .filter(e => e !== undefined);
