import * as utils from '../../../mylib/utils';

import { DCardPathType } from './dcard-path-type';
import { PlayerCards, IPlayerCardsJS } from './player-cards';
import { DCard, IDCardJS, toDCardList, toDCardJSArray } from './dcard';
import { TurnInfo, ITurnInfoJS, defaultValuesJS as defaultTurnInfoJS } from './turn-info';
import { PlayerData, IPlayerDataJS } from './players-data';
import { BasicCards, IBasicCardsJS, defaultValuesJS as defaultBasicCardsJS } from './basic-cards';
import { KingdomCards, IKingdomCardsJS, defaultValuesJS as defaultKingdomCardsJS } from './kingdom-cards';
import { getDCardsByIdArray } from '../../../functions/dominion/get-dcards-by-id-array';
import { withDefault } from '../../../mylib/utils';
import { List as IList, Record } from 'immutable';



export interface IGameStateJS {
  turnCounter: number;
  nofPlayers:  number;
  Prosperity:  boolean;
  usePotion:   boolean;
  turnInfo:       ITurnInfoJS;
  allPlayersData: IPlayerDataJS[];
  DCards: {
    allPlayersCards: IPlayerCardsJS[],
    BasicCards:      IBasicCardsJS,
    KingdomCards:    IKingdomCardsJS,
    trashPile:       IDCardJS[],
    BlackMarketPile: IDCardJS[],
  };
}

interface IGameState {
  turnCounter: number;
  nofPlayers:  number;
  Prosperity:  boolean;
  usePotion:   boolean;
  turnInfo:       TurnInfo;
  allPlayersData: IList<PlayerData>;
  DCards: {
    allPlayersCards: IList<PlayerCards>,
    BasicCards:      BasicCards,
    KingdomCards:    KingdomCards,
    trashPile:       IList<DCard>,
    BlackMarketPile: IList<DCard>,
  };
}

export const defaultValuesJS = (): IGameStateJS => ({
  turnCounter    : 0,
  nofPlayers     : 0,
  Prosperity     : false,
  usePotion      : false,
  turnInfo       : defaultTurnInfoJS(),
  allPlayersData : [],
  DCards: {
    allPlayersCards : [],
    BasicCards      : defaultBasicCardsJS(),
    KingdomCards    : defaultKingdomCardsJS(),
    trashPile       : [],
    BlackMarketPile : [],
  },
});

const defaultValues = (): IGameState => ({
  turnCounter    : 0,
  nofPlayers     : 0,
  Prosperity     : false,
  usePotion      : false,
  turnInfo       : new TurnInfo(),
  allPlayersData : IList(),
  DCards: {
    allPlayersCards : IList(),
    BasicCards      : new BasicCards(),
    KingdomCards    : new KingdomCards(),
    trashPile       : IList(),
    BlackMarketPile : IList(),
  },
});


const GameStateRecord = Record(defaultValues());

export class GameState extends GameStateRecord {
  constructor(init: Partial<IGameStateJS> = defaultValuesJS()) {
    super((() => {
      const dfl = defaultValuesJS();
      const wd = withDefault(init, dfl);
      const wdDCards = withDefault(wd("DCards"), dfl.DCards);
      return {
        turnCounter    : wd("turnCounter"),
        nofPlayers     : wd("nofPlayers"),
        Prosperity     : wd("Prosperity"),
        usePotion      : wd("usePotion"),
        turnInfo       : new TurnInfo(init.turnInfo),
        allPlayersData : IList(wd("allPlayersData"))
                            .map(e => new PlayerData(e)),
        DCards         : {
          allPlayersCards : IList(wdDCards("allPlayersCards"))
                              .map(e => new PlayerCards(e)),
          BasicCards      : new BasicCards(wdDCards("BasicCards")),
          KingdomCards    : new KingdomCards(wdDCards("KingdomCards")),
          trashPile       : toDCardList(wdDCards("trashPile")),
          BlackMarketPile : toDCardList(wdDCards("BlackMarketPile")),
        },
      };
    })());
  }

  toJSData = (): IGameStateJS => ({
    turnCounter    : this.turnCounter,
    nofPlayers     : this.nofPlayers,
    Prosperity     : this.Prosperity,
    usePotion      : this.usePotion,
    turnInfo       : this.turnInfo.toJSData(),
    allPlayersData : this.allPlayersData.map(e => e.toJSData()).toArray(),
    DCards         : {
      allPlayersCards : this.DCards.allPlayersCards.map(e => e.toJSData()).toArray(),
      BasicCards      : this.DCards.BasicCards.toJSData(),
      KingdomCards    : this.DCards.KingdomCards.toJSData(),
      trashPile       : toDCardJSArray(this.DCards.trashPile),
      BlackMarketPile : toDCardJSArray(this.DCards.BlackMarketPile),
    },
  })


  incrementTurnCounter = (): GameState =>
    this.set('turnCounter', this.turnCounter + 1)

  setNumberOfPlayers = (nofPlayers: number): GameState => {
    return this.set('nofPlayers', nofPlayers);
    // const seq = utils.numberUtils.seq0(nofPlayers);
    // if ( this.allPlayersData.length === 0 ) {
    //   this.allPlayersData = seq.map( () => new PlayerData() );
    // }
    // if ( this.DCards.allPlayersCards.length === 0 ) {
    //   this.DCards.allPlayersCards = seq.map( () => new PlayerCards() );
    // }
  }

  turnPlayerIndex = (): number =>
    ((this.turnCounter % this.nofPlayers) || 0)

  nextTurnPlayerIndex = (): number =>
    (((this.turnCounter + 1) % this.nofPlayers) || 0)

  turnPlayerCards = (): PlayerCards =>
    this.DCards.allPlayersCards.get(this.turnPlayerIndex(), new PlayerCards())

  turnPlayerData = (): PlayerData =>
    this.allPlayersData.get(this.turnPlayerIndex(), new PlayerData())

  getDirectory(cardId: number): DCardPathType[] {
    let result: DCardPathType[] = [];
    this.DCards.allPlayersCards.forEach( (playerCards, playerIndex) =>
      utils.objectUtils.forEach( playerCards.toJSData(), (pile, key) => {
        if ( pile.map( c => c.id ).includes( cardId ) ) {
          result = ['allPlayersCards', playerIndex, key] as DCardPathType[];
        }
      }) );

    // utils.objectUtils.forEach( this.DCards.BasicCards.toJSData(), (pile: IList<DCard>, key) => {
    //   if ( pile.map( c => c.id ).includes( cardId ) ) {
    //     result = ['BasicCards', key] as DCardPathType[];
    //   }
    // });

    if ( this.DCards.BlackMarketPile.map( c => c.id ).includes( cardId ) ) {
      result = ['BlackMarketPile'];
    }

    this.DCards.KingdomCards.forEach( (pile, index) => {
      if ( pile.map( c => c.id ).includes( cardId ) ) {
        result = ['KingdomCards', index];
      }
    });

    if ( this.DCards.trashPile.map( c => c.id ).includes( cardId ) ) {
      result = ['trashPile'];
    }

    return result;
  }


  getAllPlayersCards = (): IList<DCard> =>
    IList().concat(
      ...this.DCards.allPlayersCards.map( pl => pl.getAllDCards() ) )

  getAllDCards = (): IList<DCard> =>
    IList().concat(
      this.getAllPlayersCards(),
      this.DCards.BasicCards.getAllDCards(),
      this.DCards.KingdomCards.getAllDCards(),
      this.DCards.trashPile,
      this.DCards.BlackMarketPile )

  isEmpty = (): boolean =>
    this.getAllDCards().isEmpty()

  getDCards = (cardIdArray: IList<number>): IList<DCard> =>
    getDCardsByIdArray(this.getAllDCards(), cardIdArray)

  getDCard = (cardId: number): DCard =>
    this.getDCards(IList([cardId])).get(0, new DCard())

  removeDCards = (cardIdArray: IList<number>): void => {
    this.DCards.allPlayersCards.forEach(pl => pl.removeDCards(cardIdArray));
    // this.DCards.BasicCards.removeDCards( cardIdArray );
    // this.DCards.KingdomCards.removeDCards( cardIdArray );
    // this.DCards.trashPile
    //   = this.DCards.trashPile.filter( c => !cardIdArray.includes(c.id) );
    // this.DCards.BlackMarketPile
    //   = this.DCards.BlackMarketPile.filter( c => !cardIdArray.includes(c.id) );
  }

  emptyPiles = (): number => {
    // const Supplies = IList().concat(
    //     // utils.object.entries( this.DCards.BasicCards ),  // TODO
    //     utils.objectUtils.values(this.DCards.BasicCards.),
    //     this.DCards.KingdomCards );
    // return Supplies.filter( e => e.length <= 0 ).length
    //         - (this.Prosperity ? 0 : 2)
    //         - (this.usePotion ? 0 : 1);
    return 0;
  }

  // 使用しているサプライが3山なくなったら終了
  /* TODO 闇市場，廃墟などもカウント */
  gameIsOverConditions = (): boolean =>
    (this.DCards.BasicCards.Province.isEmpty()
        || (this.Prosperity && this.DCards.BasicCards.Colony.isEmpty())
        || this.emptyPiles() >= 3 )

  gameIsOver = (): boolean =>
    this.isEmpty()
      ? false
      : this.turnInfo.phase === 'GameIsOver' && this.gameIsOverConditions()

  disableAllButtons = (): void => {
    this.getAllDCards()
      .forEach(d => d.isButton.forEach((_, i, ar) => ar[i] = false));
  }
}
