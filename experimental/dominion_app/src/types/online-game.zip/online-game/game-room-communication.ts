import { IChatMessageJS, ChatMessage } from './chat-message';
import { IUserInputJS, UserInput } from './user-input';
import { withDefault } from '../../../mylib/utils';
import { List as IList, Record } from 'immutable';


export interface IGameCommunicationJS {
  databaseKey:       string;
  chatList:          IChatMessageJS[];
  userInputList:     IUserInputJS[];
  resetGameClicked:  number;
  thinkingState:     boolean[];
  presenceState:     boolean[];
  isTerminated:      boolean;
  resultIsSubmitted: boolean;
}

interface IGameCommunication {
  databaseKey:       string;
  chatList:          IList<ChatMessage>;
  userInputList:     IList<UserInput>;
  resetGameClicked:  number;
  thinkingState:     IList<boolean>;
  presenceState:     IList<boolean>;
  isTerminated:      boolean;
  resultIsSubmitted: boolean;
}

const defaultValuesJS = (): IGameCommunicationJS => ({
  databaseKey        : '',
  chatList           : [],
  userInputList      : [],
  resetGameClicked   : 0,
  thinkingState      : [],
  presenceState      : [],
  isTerminated       : false,
  resultIsSubmitted  : false,
});

const defaultValues = (): IGameCommunication => ({
  databaseKey        : '',
  chatList           : IList(),
  userInputList      : IList(),
  resetGameClicked   : 0,
  thinkingState      : IList(),
  presenceState      : IList(),
  isTerminated       : false,
  resultIsSubmitted  : false,
});


const GameCommunicationRecord = Record(defaultValues());


export class GameCommunication extends GameCommunicationRecord {
  constructor(init: Partial<IGameCommunicationJS> = defaultValuesJS()) {
    super((() => {
      const dfl = defaultValuesJS();
      const wd = withDefault(init, dfl);
      return {
        databaseKey       : wd("databaseKey"),
        resetGameClicked  : wd("resetGameClicked"),
        thinkingState     : IList(wd("thinkingState")),
        presenceState     : IList(wd("presenceState")),
        isTerminated      : wd("isTerminated"),
        resultIsSubmitted : wd("resultIsSubmitted"),
        chatList          : IList(wd("chatList")).map(e => new ChatMessage(e)),
        userInputList     : IList(wd("userInputList")).map(e => new UserInput(e)),
      };
    })());
  }

  toJSData = (): IGameCommunicationJS => ({
    databaseKey       : this.databaseKey,
    resetGameClicked  : this.resetGameClicked,
    thinkingState     : this.thinkingState.toArray(),
    presenceState     : this.presenceState.toArray(),
    isTerminated      : this.isTerminated,
    resultIsSubmitted : this.resultIsSubmitted,
    chatList          : this.chatList.map(e => e.toJSData()).toArray(),
    userInputList     : this.userInputList.map(e => e.toJSData()).toArray(),
  })
}
