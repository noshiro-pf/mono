import { SelectedCardsRecordFactory, ISelectedCardsJS, defaultValuesJS as defaultSelectedCardsJS } from '../../../types/dominion/selected-cards';
import { GameState, IGameStateJS, defaultValuesJS as defaultGameStateJS } from './game-state';
import { DCardProperty } from '../dcard-property';
import { withDefault } from '../../../mylib/utils';
import { List as IList, Record } from 'immutable';



export interface IGameRoomJS {
  databaseKey:        string;
  nofPlayers:         number;
  memo:               string;
  selectedExpansions: string[];
  playerShuffler:     number[];
  playersNameList:    string[];
  communicationId:    string;
  timestamp:          number;
  selectedCards:      ISelectedCardsJS;
  initialState:       IGameStateJS;
}

interface IGameRoom {
  databaseKey:        string;
  nofPlayers:         number;
  memo:               string;
  selectedExpansions: IList<string>;
  playerShuffler:     IList<number>;
  playersNameList:    IList<string>;
  communicationId:    string;
  timestamp:          number;
  selectedCards:      SelectedCardsRecord;
  initialState:       GameState;
}

const defaultValuesJS = (): IGameRoomJS => ({
  databaseKey          : '',
  nofPlayers           : 2,
  memo                 : '',
  selectedExpansions   : [],
  playerShuffler       : [],
  playersNameList      : [],
  communicationId      : '',
  timestamp            : Date.now(),
  selectedCards        : defaultSelectedCardsJS(),
  initialState         : defaultGameStateJS(),
});

const defaultValues = (): IGameRoom => ({
  databaseKey          : '',
  nofPlayers           : 2,
  memo                 : '',
  selectedExpansions   : IList(),
  playerShuffler       : IList(),
  playersNameList      : IList(),
  communicationId      : '',
  timestamp            : Date.now(),
  selectedCards        : new SelectedCards(),
  initialState         : new GameState(),
});


const GameRoomRecord = Record(defaultValues());

export class GameRoom extends GameRoomRecord {
  constructor(init: Partial<IGameRoomJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        databaseKey        : wd("databaseKey"),
        nofPlayers         : wd("nofPlayers"),
        memo               : wd("memo"),
        selectedExpansions : IList(wd("selectedExpansions")),
        playerShuffler     : IList(wd("playerShuffler")),
        playersNameList    : IList(wd("playersNameList")),
        communicationId    : wd("communicationId"),
        timestamp          : wd("timestamp"),
        selectedCards      : new SelectedCards(wd("selectedCards")),
        initialState       : new GameState(wd("initialState")),
      };
    })());
  }

  toJSData = (): IGameRoomJS => ({
    databaseKey        : this.databaseKey,
    nofPlayers         : this.nofPlayers,
    memo               : this.memo,
    selectedExpansions : this.selectedExpansions.toArray(),
    playerShuffler     : this.playerShuffler.toArray(),
    playersNameList    : this.playersNameList.toArray(),
    communicationId    : this.communicationId,
    timestamp          : this.timestamp,
    selectedCards      : this.selectedCards.toJSData(),
    initialState       : this.initialState.toJSData(),
  })


  playersNameShuffled = (): IList<string> =>
    this.playersNameList
    .map((_, i) => this.playersNameList.get(this.playerShuffler.get(i, 0), ''))


  initCards = (_dcardlist: IList<DCardProperty>) => {
    // this.initialState.Prosperity = this.selectedCards.Prosperity;

    // let serialNumber = 0;

    // const addCard = (cardListIndex: number, placePath: (string|number)[]) => {
    //   serialNumber++;
    //   const card = new DCard({
    //     id       : serialNumber,
    //     cardprop : dcardlist.get(cardListIndex, new DCardProperty()),
    //     faceUp   : Range(0, this.nofPlayers).map(_ => true).toList(),
    //     isButton : Range(0, this.nofPlayers).map(_ => false).toList(),
    //   });

    //   let ref: any = this.initialState.DCards;
    //   for (const p of placePath) {
    //     ref = ref[p];
    //   }
    //   ref.push(card);
    // };

    // const addMultipleCards = (placePath: (string|number)[], cardListIndex: number) => {
    //     const N = pileSize(
    //                 dcardlist,
    //                 cardListIndex,
    //                 this.nofPlayers,
    //                 this.selectedCards.DarkAges );
    //     for (let i = 0; i < N; ++i) {
    //       addCard( cardListIndex, placePath );
    //     }
    //   };

    // const toCardPropIndex = (cardId: string) => toListIndex(dcardlist, cardId);

    // // basic cards
    // addMultipleCards(['BasicCards', 'Curse'   ], toCardPropIndex('Curse'   ));
    // addMultipleCards(['BasicCards', 'Copper'  ], toCardPropIndex('Copper'  ));
    // addMultipleCards(['BasicCards', 'Silver'  ], toCardPropIndex('Silver'  ));
    // addMultipleCards(['BasicCards', 'Gold'    ], toCardPropIndex('Gold'    ));
    // addMultipleCards(['BasicCards', 'Estate'  ], toCardPropIndex('Estate'  ));
    // addMultipleCards(['BasicCards', 'Duchy'   ], toCardPropIndex('Duchy'   ));
    // addMultipleCards(['BasicCards', 'Province'], toCardPropIndex('Province'));
    // if (this.selectedCards.Prosperity) {
    //   addMultipleCards(['BasicCards', 'Platinum'], toCardPropIndex('Platinum'));
    //   addMultipleCards(['BasicCards', 'Colony'  ], toCardPropIndex('Colony'  ));
    // }
    // if (this.selectedCards.usePotion(dcardlist)) {
    //   addMultipleCards(['BasicCards', 'Potion'], toCardPropIndex('Potion'));
    // }

    // // KingdomCards

    // this.selectedCards.KingdomCards10
    //   .sort( (i, j) => (
    //         dcardlist.get(i, new DCardProperty()).effects.cost.coin
    //       - dcardlist.get(j, new DCardProperty()).effects.cost.coin))  // TODO: デフォルト値付きgetメソッドを持つdcardlist型の定義
    //   .forEach( (cardPropIndex, index) => {
    //     addMultipleCards( ['KingdomCards', index], cardPropIndex );
    //   });
  }



  initDecks = () => {
    // for (let index = 0; index < this.nofPlayers; ++index) {
    //   const playerCards = new PlayerCards();
    //   /* get 7 Coppers from supply */
    //   for (let i = 0; i < 7; ++i) {
    //     const top = this.initialState.DCards.BasicCards.Copper.pop();
    //     if (!!top) playerCards.Deck.push(top);
    //   }
    //   /* get 3 Estates from supply */
    //   for (let i = 0; i < 3; ++i) {
    //     const top = this.initialState.DCards.BasicCards.Estate.pop();
    //     if (!!top) playerCards.Deck.push(top);
    //   }

    //   playerCards.Deck.forEach(c => c.faceUp = c.faceUp.map(() => false));

    //   utils.numberUtils.random.shuffle(playerCards.Deck);

    //   for (let i = 0; i < 5; ++i) {
    //     const top = playerCards.Deck.pop();
    //     if (!!top) playerCards.HandCards.push(top);
    //   }

    //   // face up own HandCards
    //   playerCards.HandCards.forEach(c => {
    //     c.faceUp  [index] = true;
    //     c.isButton[index] = c.cardprop.cardTypes.includes('Action');
    //   });

    //   playerCards.sortHandCards();

    //   this.initialState.DCards.allPlayersCards.push(playerCards);
    // }
  }



  waitingForNewPlayers = (): boolean =>
    (this.playersNameList.size < this.nofPlayers)
}
