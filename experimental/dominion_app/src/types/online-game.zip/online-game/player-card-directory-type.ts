export type PlayerCardDirectoryType = 'Deck'
                                     |'DiscardPile'
                                     |'HandCards'
                                     |'PlayArea'
                                     |'Aside'
                                     |'Open';
