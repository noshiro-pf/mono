import { DCardProperty, IDCardPropertyJS, defaultValuesJS as defaultDCardPropertyJS } from '../dcard-property';
import { withDefault, listUtils } from '../../../mylib/utils';
import { List as IList, Record } from 'immutable';
import { DCardType } from '../card-type';


export interface IDCardJS {  // Dominion card
  cardprop:  IDCardPropertyJS;
  id:        number;
  faceUp:    boolean[];
  isButton:  boolean[];
  rotation:  number;  // 0 - 360
}

interface IDCard {  // Dominion card
  cardprop:  DCardProperty;
  id:        number;
  faceUp:    IList<boolean>;
  isButton:  IList<boolean>;
  rotation:  number;  // 0 - 360
}

export const defaultValuesJS = (): IDCardJS => ({
  cardprop : defaultDCardPropertyJS(),
  id       : 0,
  faceUp   : [],
  isButton : [],
  rotation : 0,
});

const defaultValues = (): IDCard => ({
  cardprop : new DCardProperty(),
  id       : 0,
  faceUp   : IList(),
  isButton : IList(),
  rotation : 0,
});


const DCardRecord = Record(defaultValues());

export class DCard extends DCardRecord {  // Dominion card
  constructor(init: Partial<IDCardJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        cardProperty : new DCardProperty(wd("cardprop")),
        id           : wd("id"),
        faceUp       : IList(wd("faceUp")),
        isButton     : IList(wd("isButton")),
        rotation     : wd("rotation"),
      };
    })());
  }

  toJSData = (): IDCardJS => ({
    cardprop : this.cardprop.toJSData(),
    id           : this.id,
    faceUp       : this.faceUp.toArray(),
    isButton     : this.isButton.toArray(),
    rotation     : this.rotation,
  })
}


export const getFiltered = (cardIdArray: IList<number>, pile: IList<DCard>) =>
  pile.filter(c => !cardIdArray.includes(c.id));

export const toDCardList = (src: IDCardJS[] = []) =>
  IList(src.map(e => new DCard(e)));

export const toDCardJSArray = (src: IList<DCard>) =>
  src.map(e => e.toJSData()).toArray();

export const sortByCardType = (dcards: IList<DCard>): IList<DCard> => {
  let sorted = dcards.sort((a, b) => a.cardprop.index - b.cardprop.index);
  let Actions;
  let Treasures;
  let Victories;
  const f = (type: DCardType) => ((d: DCard) => d.cardprop.cardTypes.includes(type));
  [Actions,   sorted] = listUtils.filterRemove(sorted, f('Action'));
  [Treasures, sorted] = listUtils.filterRemove(sorted, f('Treasure'));
  [Victories, sorted] = listUtils.filterRemove(sorted, f('Victory'));
  return IList().concat(Actions, Treasures, Victories, sorted);
};
