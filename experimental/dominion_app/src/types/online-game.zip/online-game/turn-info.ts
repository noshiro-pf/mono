import { PhaseType } from './phase-type';
import { withDefault } from '../../../mylib/utils';
import { List as IList, Record } from 'immutable';


export interface ITurnInfoJS {
  action: number;
  buy:    number;
  coin:   number;
  potion: number;
  phase:  PhaseType;
  runningCards: { cardId: string, phase: number }[];
}

interface ITurnInfo {
  action: number;
  buy:    number;
  coin:   number;
  potion: number;
  phase:  PhaseType;
  runningCards: IList<{ cardId: string, phase: number }>;  // TODO: use map
}

export const defaultValuesJS = (): ITurnInfoJS => ({
  action       : 1,
  buy          : 1,
  coin         : 0,
  potion       : 0,
  phase        : '',
  runningCards : [],
});

const defaultValues = (): ITurnInfo => ({
  action       : 1,
  buy          : 1,
  coin         : 0,
  potion       : 0,
  phase        : '',
  runningCards : IList(),
});


const TurnInfoRecord = Record(defaultValues());


export class TurnInfo extends TurnInfoRecord {
  constructor(init: Partial<ITurnInfoJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        action       : wd("action"),
        buy          : wd("buy"),
        coin         : wd("coin"),
        potion       : wd("potion"),
        phase        : wd("phase"),
        runningCards : IList(wd("runningCards")),
      };
    })());
  }

  toJSData = (): ITurnInfoJS => ({
    action       : this.action,
    buy          : this.buy,
    coin         : this.coin,
    potion       : this.potion,
    phase        : this.phase,
    runningCards : this.runningCards.toArray(),
  })
}
