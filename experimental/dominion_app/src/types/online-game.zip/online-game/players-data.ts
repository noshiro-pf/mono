import { withDefault } from '../../../mylib/utils';
import { Record } from 'immutable';

export interface IPlayerDataJS {
  VPtoken: number;
  vcoin:   number;
  debt:    number;
}

type IPlayerData = IPlayerDataJS;

export const defaultValuesJS = (): IPlayerData => ({
  VPtoken: 0,
  vcoin: 0,
  debt: 0,
});

const defaultValues = (): IPlayerData => defaultValuesJS();


const PlayerDataRecord = Record(defaultValues());

export class PlayerData extends PlayerDataRecord {
  constructor(init: Partial<IPlayerDataJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        VPtoken : wd("VPtoken"),
        vcoin   : wd("vcoin"),
        debt    : wd("debt"),
      };
    })());
  }

  toJSData = (): IPlayerDataJS => ({
    VPtoken : this.VPtoken,
    vcoin   : this.vcoin,
    debt    : this.debt,
  })
}
