export type UserInputCommandType = ''
                                  |'clicked card'
                                  |'clicked vcoin'
                                  |'clicked debt'
                                  |'clicked goToNextPhase'
                                  |'clicked finishMyTurn'
                                  |'clicked sortHandcards'
                                  |'play all treasures'
                                  |'increment turnCounter'  // test
                                 ;
