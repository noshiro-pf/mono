import { toDCardList, getFiltered, DCard, IDCardJS, sortByCardType, toDCardJSArray } from './dcard';
import { getDCardsByIdArray } from '../../../functions/dominion/get-dcards-by-id-array';
import { withDefault } from '../../../mylib/utils';
import { List as IList, Record } from 'immutable';


export interface IPlayerCardsJS {
  Deck:        IDCardJS[];
  DiscardPile: IDCardJS[];
  HandCards:   IDCardJS[];
  PlayArea:    IDCardJS[];
  Aside:       IDCardJS[];
  Open:        IDCardJS[];
}

interface IPlayerCards {
  Deck:        IList<DCard>;
  DiscardPile: IList<DCard>;
  HandCards:   IList<DCard>;
  PlayArea:    IList<DCard>;
  Aside:       IList<DCard>;
  Open:        IList<DCard>;
}

export const defaultValuesJS = (): IPlayerCardsJS => ({
  Deck        : [],
  DiscardPile : [],
  HandCards   : [],
  PlayArea    : [],
  Aside       : [],
  Open        : [],
});

const defaultValues = (): IPlayerCards => ({
  Deck        : IList(),
  DiscardPile : IList(),
  HandCards   : IList(),
  PlayArea    : IList(),
  Aside       : IList(),
  Open        : IList(),
});


const PlayerCardsRecord = Record(defaultValues());

export class PlayerCards extends PlayerCardsRecord {
  constructor(init: Partial<IPlayerCardsJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        Deck        : toDCardList(wd("Deck")),
        DiscardPile : toDCardList(wd("DiscardPile")),
        HandCards   : toDCardList(wd("HandCards")),
        PlayArea    : toDCardList(wd("PlayArea")),
        Aside       : toDCardList(wd("Aside")),
        Open        : toDCardList(wd("Open")),
      };
    })());
  }

  toJSData = (): IPlayerCardsJS => ({
    Deck        : toDCardJSArray(this.Deck),
    DiscardPile : toDCardJSArray(this.DiscardPile),
    HandCards   : toDCardJSArray(this.HandCards),
    PlayArea    : toDCardJSArray(this.PlayArea),
    Aside       : toDCardJSArray(this.Aside),
    Open        : toDCardJSArray(this.Open),
  })

  sortHandCards = (): PlayerCards =>
    this.set('HandCards', sortByCardType(this.HandCards))

  getAllDCards = (): IList<DCard> => IList().concat(
    this.Deck,
    this.DiscardPile,
    this.HandCards,
    this.PlayArea,
    this.Aside,
    this.Open,
  )

  getDCards = (cardIdArray: IList<number>, sort: boolean = false): IList<DCard> => {
    const dcards = getDCardsByIdArray(this.getAllDCards(), cardIdArray);
    return (sort ? sortByCardType(dcards) : dcards);
  }

  removeDCards = (cardIdArray: IList<number>): PlayerCards => {
    const a = this.set('Deck',        getFiltered(cardIdArray, this.Deck       ));
    const b = a.set('DiscardPile', getFiltered(cardIdArray, a.DiscardPile));
    const c = b.set('HandCards',   getFiltered(cardIdArray, b.HandCards  ));
    const d = c.set('PlayArea',    getFiltered(cardIdArray, c.PlayArea   ));
    const e = d.set('Aside',       getFiltered(cardIdArray, d.Aside      ));
    const f = e.set('Open',        getFiltered(cardIdArray, e.Open       ));
    return f;
  }
}
