import { List as IList, Record } from 'immutable';

import { DCard, getFiltered, toDCardList, IDCardJS, toDCardJSArray } from './dcard';
import { getDCardsByIdArray } from '../../../functions/dominion/get-dcards-by-id-array';
import { withDefault } from '../../../mylib/utils';


export interface IBasicCardsJS {
  Curse:    IDCardJS[];
  Copper:   IDCardJS[];
  Silver:   IDCardJS[];
  Gold:     IDCardJS[];
  Estate:   IDCardJS[];
  Duchy:    IDCardJS[];
  Province: IDCardJS[];
  Platinum: IDCardJS[];
  Colony:   IDCardJS[];
  Potion:   IDCardJS[];
}

interface IBasicCards {
  Curse:    IList<DCard>;
  Copper:   IList<DCard>;
  Silver:   IList<DCard>;
  Gold:     IList<DCard>;
  Estate:   IList<DCard>;
  Duchy:    IList<DCard>;
  Province: IList<DCard>;
  Platinum: IList<DCard>;
  Colony:   IList<DCard>;
  Potion:   IList<DCard>;
}

export const defaultValuesJS = (): IBasicCardsJS => ({
  Curse    : [],
  Copper   : [],
  Silver   : [],
  Gold     : [],
  Estate   : [],
  Duchy    : [],
  Province : [],
  Platinum : [],
  Colony   : [],
  Potion   : [],
});

const defaultValues = (): IBasicCards => ({
  Curse    : IList(),
  Copper   : IList(),
  Silver   : IList(),
  Gold     : IList(),
  Estate   : IList(),
  Duchy    : IList(),
  Province : IList(),
  Platinum : IList(),
  Colony   : IList(),
  Potion   : IList(),
});


const BasicCardsRecord = Record(defaultValues());

export class BasicCards extends BasicCardsRecord {
  constructor(init: Partial<IBasicCardsJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        Curse    : toDCardList(wd("Curse"   )),
        Copper   : toDCardList(wd("Copper"  )),
        Silver   : toDCardList(wd("Silver"  )),
        Gold     : toDCardList(wd("Gold"    )),
        Estate   : toDCardList(wd("Estate"  )),
        Duchy    : toDCardList(wd("Duchy"   )),
        Province : toDCardList(wd("Province")),
        Platinum : toDCardList(wd("Platinum")),
        Colony   : toDCardList(wd("Colony"  )),
        Potion   : toDCardList(wd("Potion"  )),
      };
    })());
  }


  toJSData = (): IBasicCardsJS => ({
    Curse    : toDCardJSArray(this.Curse),
    Copper   : toDCardJSArray(this.Copper),
    Silver   : toDCardJSArray(this.Silver),
    Gold     : toDCardJSArray(this.Gold),
    Estate   : toDCardJSArray(this.Estate),
    Duchy    : toDCardJSArray(this.Duchy),
    Province : toDCardJSArray(this.Province),
    Platinum : toDCardJSArray(this.Platinum),
    Colony   : toDCardJSArray(this.Colony),
    Potion   : toDCardJSArray(this.Potion),
  })

  getAllDCards = (): IList<DCard> => IList().concat(
      this.Curse,
      this.Copper,
      this.Silver,
      this.Gold,
      this.Estate,
      this.Duchy,
      this.Province,
      this.Platinum,
      this.Colony,
      this.Potion,
    )

  getDCardsByIdArray = (cardIdArray: IList<number>): IList<DCard> =>
    getDCardsByIdArray(this.getAllDCards(), cardIdArray)

  removeDCards = (cardIdArray: IList<number>): void => {  // TODO
    console.log(getFiltered(cardIdArray, this.Curse));
    // this.Curse    = getFiltered( cardIdArray, this.Curse    );
    // this.Copper   = getFiltered( cardIdArray, this.Copper   );
    // this.Silver   = getFiltered( cardIdArray, this.Silver   );
    // this.Gold     = getFiltered( cardIdArray, this.Gold     );
    // this.Estate   = getFiltered( cardIdArray, this.Estate   );
    // this.Duchy    = getFiltered( cardIdArray, this.Duchy    );
    // this.Province = getFiltered( cardIdArray, this.Province );
    // this.Platinum = getFiltered( cardIdArray, this.Platinum );
    // this.Colony   = getFiltered( cardIdArray, this.Colony   );
    // this.Potion   = getFiltered( cardIdArray, this.Potion   );
  }
}
