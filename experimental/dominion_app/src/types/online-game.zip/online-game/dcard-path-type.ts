import { PlayerCardDirectoryType } from './player-card-directory-type';
import { BasicCardsDirectoryType } from './basic-cards-directory-type';


export type DCardPathType = number
                          |PlayerCardDirectoryType
                          |BasicCardsDirectoryType
                          |'allPlayersCards'
                          |'BasicCards'
                          |'KingdomCards'
                          |'trashPile'
                          |'BlackMarketPile'
                        ;
