import { withDefault } from '../../../mylib/utils';
import { Record } from 'immutable';

export type ChatCommand = ''|'leaveTheRoom';


export interface IChatMessageJS {
  playerName: string;
  content:    string;
  command:    ChatCommand;
  date:       string;
}

type IChatMessage = IChatMessageJS;

export const defaultValuesJS = (): IChatMessageJS => ({
  playerName : '',
  content    : '',
  command    : '',
  date       : (new Date()).toLocaleString(),
});

const defaultValues = (): IChatMessage => defaultValuesJS();


const ChatMessageRecord = Record(defaultValues());

export class ChatMessage extends ChatMessageRecord {
  constructor(init: Partial<IChatMessageJS> = defaultValuesJS()) {
    super((() => {
      const wd = withDefault(init, defaultValuesJS());
      return {
        playerName : wd('playerName'),
        content    : wd('content'),
        command    : wd('command'),
        date       : wd('date'),
      };
    })());
  }

  toJSData = (): IChatMessageJS => ({
    playerName : this.playerName,
    content    : this.content,
    command    : this.command,
    date       : this.date,
  })
}
