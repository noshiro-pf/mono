import { UserInputCommandType } from './user-input-command-type';
import { withDefault } from '../../../mylib/utils';
import { Record } from 'immutable';


export interface IUserInputJS {
  command: UserInputCommandType;
  index: number;
  data: {
    playerId: number,
    autoSort: boolean,
    clickedCardId: number,
  };
}

type IUserInput = IUserInputJS;

export const defaultValuesJS = (): IUserInputJS => ({
  command: '',
  index: 0,
  data: {
    playerId: 0,
    autoSort: true,
    clickedCardId: 0,
  },
});

const defaultValues = (): IUserInput => defaultValuesJS();


const UserInputRecord = Record(defaultValues());

export class UserInput extends UserInputRecord {
  constructor(init: Partial<IUserInputJS> = defaultValuesJS()) {
    super((() => {
      const dfl = defaultValuesJS();
      const wd = withDefault(init, dfl);
      const wdData = withDefault(wd("data"), dfl.data);
      return {
        command : wd("command"),
        index   : wd("index"),
        data    : {
          playerId      : wdData("playerId"),
          autoSort      : wdData("autoSort"),
          clickedCardId : wdData("clickedCardId"),
        },
      };
    })());
  }

  toJSData = (): IUserInputJS => ({
    command : this.command,
    index   : this.index,
    data    : {
      playerId      : this.data.playerId,
      autoSort      : this.data.autoSort,
      clickedCardId : this.data.clickedCardId,
    },
  })
}
