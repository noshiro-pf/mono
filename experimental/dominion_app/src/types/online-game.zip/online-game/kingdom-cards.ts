import { DCard, IDCardJS } from './dcard';
import { getDCardsByIdArray } from '../../../functions/dominion/get-dcards-by-id-array';
import { List as IList, Range, Record } from 'immutable';



export type IKingdomCardsJS = IDCardJS[][];

type IKingdomCards = IList<IList<DCard>>;


export const defaultValuesJS = (): IKingdomCardsJS =>
  Range(0, 10).map(() => []).toArray();


const defaultValues = (): IKingdomCards =>
  Range(0, 10).map(() => IList()).toList();


const KingdomCardsRecord = Record(defaultValues());

export class KingdomCards extends KingdomCardsRecord {
  constructor(init: Partial<IKingdomCardsJS> = defaultValuesJS()) {
    super(
      Range(0, 10)
        .map(i => IList((init[i] || []).map(e => new DCard(e))))
        .toList()
    );
  }

  toJSData = (): IKingdomCardsJS =>
    Range(0, 10).map(i => this.get(i, IList()).toArray()).toArray()

  getAllDCards = (): IList<DCard> =>
    IList().concat(
      Range(0, 10).map(i => this.get(i, IList<DCard>())).toList()
    )


  // Arrayの拡張クラスではこの記法でないとメソッドが追加されない（？）
  getDCardsByIdArray = (cardIdArray: IList<number>): IList<DCard> =>
    getDCardsByIdArray(this.getAllDCards(), cardIdArray)

  removeDCards = (cardIdArray: IList<number>) => {  // TODO
    this.forEach((pile, key, obj) =>
      obj[key] = pile.filter(c => !cardIdArray.includes(c.id)));
  }
}
